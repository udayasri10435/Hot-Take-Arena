import { HotTake, Argument, PastCrown } from '../types';

const STORAGE_KEY_TAKES = 'hot_take_arena_takes_v1';
const STORAGE_KEY_VOTES = 'hot_take_arena_user_votes_v1';
const STORAGE_KEY_COMMENTS = 'hot_take_arena_comments_v1';
const STORAGE_KEY_SOUND = 'hot_take_arena_sound_v1';

export function calculateControversy(agree: number, disagree: number): number {
  const total = agree + disagree;
  if (total === 0) return 0;
  
  // Balance: 1.0 when 50/50, 0.0 when 100/0
  const ratioDiff = Math.abs(agree - disagree) / total;
  const balance = 1 - ratioDiff; // 0 to 1

  // Volume weighting: high votes give confident statistical deadlock
  const volumeWeight = Math.min(1, Math.log10(total + 1) / Math.log10(1500));
  
  // Base controversy formula (0 to 100 score)
  const score = Math.round((balance * 70) + (volumeWeight * 30));
  return Math.max(0, Math.min(100, score));
}

export const INITIAL_TAKES: HotTake[] = [
  {
    id: 'take-1',
    statement: 'Pineapple on pizza is culinary genius and people who hate it just have the palate of a fussy 7-year-old.',
    elaboration: 'The acidity and sweetness cuts right through the greasy mozzarella and salty cured ham. It is scientifically the ideal sweet-savory pairing.',
    author: 'ChefSizzle',
    category: 'food',
    spiceLevel: 'spicy',
    agreeCount: 612,
    disagreeCount: 624,
    createdAt: '2026-09-27T14:20:00Z',
    isWeeklyCrown: true,
    crownWeekTitle: 'Week 39 Champion · 49.5% / 50.5% Deadlock',
    commentsCount: 184,
    tags: ['pizza', 'culinary', 'flavor-theory']
  },
  {
    id: 'take-2',
    statement: 'Remote work exposed that 75% of middle managers produce zero tangible output and exist solely to schedule meetings about meetings.',
    elaboration: 'Autonomous engineers and designers ship faster when they are not forced into 9 AM standups where people recite Jira tickets line by line.',
    author: 'AsyncEvangelist',
    category: 'workplace',
    spiceLevel: 'nuclear',
    agreeCount: 940,
    disagreeCount: 310,
    createdAt: '2026-09-26T18:05:00Z',
    commentsCount: 142,
    tags: ['remote-work', 'corporate', 'management']
  },
  {
    id: 'take-3',
    statement: 'Single-player games with unskippable 15-minute cutscenes are failed movies disguising themselves as video games.',
    elaboration: 'If you want to direct cinema, submit to Sundance. I bought a controller to press buttons, not watch two CGI characters whisper in a muddy forest.',
    author: 'ButtonMasher99',
    category: 'gaming',
    spiceLevel: 'spicy',
    agreeCount: 521,
    disagreeCount: 498,
    createdAt: '2026-09-28T09:12:00Z',
    commentsCount: 89,
    tags: ['gaming', 'storytelling', 'game-design']
  },
  {
    id: 'take-4',
    statement: 'Coffee culture has been completely hijacked by sugar milkshakes masquerading as morning fuel.',
    elaboration: 'Ordering an 800-calorie iced brown sugar oatmilk swirl with whipped cream is not "needing your caffeine", it is eating birthday cake before 9 AM.',
    author: 'BlackRoastOnly',
    category: 'food',
    spiceLevel: 'medium',
    agreeCount: 712,
    disagreeCount: 698,
    createdAt: '2026-09-27T21:40:00Z',
    commentsCount: 97,
    tags: ['coffee', 'wellness', 'culture']
  },
  {
    id: 'take-5',
    statement: 'Cereal is fundamentally cold soup, and cow milk is merely a chilled savory-sweet broth.',
    elaboration: 'Liquid base + suspended solids eaten with a spoon out of a bowl. Reject the propaganda of Big Breakfast, you are having gazpacho for breakfast.',
    author: 'FoodTaxonomist',
    category: 'food',
    spiceLevel: 'mild',
    agreeCount: 384,
    disagreeCount: 780,
    createdAt: '2026-09-25T11:30:00Z',
    commentsCount: 63,
    tags: ['philosophy', 'soup', 'breakfast']
  },
  {
    id: 'take-6',
    statement: 'AI code generators are actually making junior developers worse engineers by depriving them of the painful debugging lessons that forge competence.',
    elaboration: 'If you never spent 6 hours tracking a single missing semicolon or race condition, you lack the mental diagnostic model when production goes down at 3 AM.',
    author: 'OldSchoolCompiler',
    category: 'tech',
    spiceLevel: 'nuclear',
    agreeCount: 812,
    disagreeCount: 795,
    createdAt: '2026-09-28T03:15:00Z',
    commentsCount: 215,
    tags: ['ai', 'coding', 'software-eng']
  },
  {
    id: 'take-7',
    statement: 'Dark mode is wildly overrated during daylight hours and people use it as an aesthetic badge rather than for actual ocular health.',
    elaboration: 'Reading white text on pure pitch-black in high ambient sunlight causes halation and iris strain. Warm light mode with high contrast is superior.',
    author: 'SolarReader',
    category: 'tech',
    spiceLevel: 'spicy',
    agreeCount: 420,
    disagreeCount: 1150,
    createdAt: '2026-09-24T16:00:00Z',
    commentsCount: 178,
    tags: ['ui-design', 'darkmode', 'ergonomics']
  },
  {
    id: 'take-8',
    statement: 'Being "brutally honest" is almost always just an excuse for people who enjoy brutality more than they care about honesty.',
    elaboration: 'Truth delivered without empathy or tact is not courage; it is emotional carelessness dressed up as a virtue.',
    author: 'VeritasTact',
    category: 'life_philosophy',
    spiceLevel: 'medium',
    agreeCount: 1240,
    disagreeCount: 185,
    createdAt: '2026-09-23T19:22:00Z',
    commentsCount: 76,
    tags: ['psychology', 'communication', 'ethics']
  }
];

export const INITIAL_ARGUMENTS: Record<string, Argument[]> = {
  'take-1': [
    {
      id: 'arg-101',
      takeId: 'take-1',
      author: 'NapoliPurist',
      avatarSeed: 'NP',
      stance: 'disagree',
      content: 'The wet moisture content of pineapple destroys the crispness of the crust base. It turns Neapolitan dough into warm wet sponge!',
      likes: 84,
      createdAt: '2026-09-27T15:00:00Z'
    },
    {
      id: 'arg-102',
      takeId: 'take-1',
      author: 'UmamiHunter',
      avatarSeed: 'UH',
      stance: 'agree',
      content: 'Pair it with pickled jalapeños and bacon instead of plain ham. The sweet-heat-smoke trifecta will convert anyone with functioning tastebuds.',
      likes: 122,
      createdAt: '2026-09-27T15:20:00Z'
    }
  ],
  'take-6': [
    {
      id: 'arg-601',
      takeId: 'take-6',
      author: 'SpeedShipper',
      avatarSeed: 'SS',
      stance: 'disagree',
      content: 'They said the exact same thing about StackOverflow, compilers, and IDE autocomplete. Knowing what to build is 10x more important than manual boilerplate typing.',
      likes: 95,
      createdAt: '2026-09-28T04:10:00Z'
    },
    {
      id: 'arg-602',
      takeId: 'take-6',
      author: 'KernelHacker',
      avatarSeed: 'KH',
      stance: 'agree',
      content: 'Wait until someone introduces a subtle memory leak that passes the AI prompt test but silently brings down payment processing under load.',
      likes: 110,
      createdAt: '2026-09-28T05:00:00Z'
    }
  ]
};

export const PAST_CROWNS: PastCrown[] = [
  {
    week: 'Week 38',
    statement: 'Open world games have ruined video games by replacing tight 12-hour masterpieces with 80 hours of mindless fetch chores.',
    author: 'LinearStoryLover',
    category: 'Gaming',
    agreePercent: 50.2,
    disagreePercent: 49.8,
    totalVotes: 1842,
    controversyScore: 99
  },
  {
    week: 'Week 37',
    statement: 'Tipping culture in modern restaurants has evolved from rewarding service into emotional extortion subsidized by bad owners.',
    author: 'FairWageAdvocate',
    category: 'Workplace',
    agreePercent: 50.6,
    disagreePercent: 49.4,
    totalVotes: 2410,
    controversyScore: 98
  },
  {
    week: 'Week 36',
    statement: 'Audiobooks do count as reading, and insisting physical print is superior is pure snobbery.',
    author: 'AudioLover',
    category: 'Pop Culture',
    agreePercent: 49.9,
    disagreePercent: 50.1,
    totalVotes: 1530,
    controversyScore: 100
  }
];

export function getStoredTakes(): HotTake[] {
  if (typeof window === 'undefined') return INITIAL_TAKES;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_TAKES);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_TAKES, JSON.stringify(INITIAL_TAKES));
      return INITIAL_TAKES;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_TAKES;
  }
}

export function saveStoredTakes(takes: HotTake[]) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_TAKES, JSON.stringify(takes));
  } catch {
    // Ignore storage quota
  }
}

export function getUserVotes(): Record<string, 'agree' | 'disagree'> {
  if (typeof window === 'undefined') return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY_VOTES);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function saveUserVote(takeId: string, stance: 'agree' | 'disagree'): Record<string, 'agree' | 'disagree'> {
  const current = getUserVotes();
  current[takeId] = stance;
  try {
    localStorage.setItem(STORAGE_KEY_VOTES, JSON.stringify(current));
  } catch {
    // Ignore
  }
  return current;
}

export function getStoredArguments(): Record<string, Argument[]> {
  if (typeof window === 'undefined') return INITIAL_ARGUMENTS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_COMMENTS);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY_COMMENTS, JSON.stringify(INITIAL_ARGUMENTS));
      return INITIAL_ARGUMENTS;
    }
    return JSON.parse(raw);
  } catch {
    return INITIAL_ARGUMENTS;
  }
}

export function saveStoredArguments(args: Record<string, Argument[]>) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_COMMENTS, JSON.stringify(args));
  } catch {
    // Ignore
  }
}

export function getSoundSetting(): boolean {
  if (typeof window === 'undefined') return true;
  try {
    const raw = localStorage.getItem(STORAGE_KEY_SOUND);
    return raw !== null ? raw === 'true' : true;
  } catch {
    return true;
  }
}

export function setSoundSetting(enabled: boolean) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_SOUND, String(enabled));
  } catch {
    // Ignore
  }
}
