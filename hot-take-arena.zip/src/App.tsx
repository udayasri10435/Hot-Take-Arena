import React, { useState, useEffect, useMemo } from 'react';
import { 
  Flame, 
  Snowflake, 
  Trophy, 
  Search, 
  Clock, 
  Sparkles, 
  SlidersHorizontal, 
  TrendingUp, 
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import { HotTake, Argument, Category, SortMode, SpiceLevel } from './types';
import { 
  getStoredTakes, 
  saveStoredTakes, 
  getUserVotes, 
  saveUserVote, 
  getStoredArguments, 
  saveStoredArguments,
  calculateControversy,
  getSoundSetting,
  setSoundSetting
} from './utils/storage';
import { sound } from './utils/audio';
import { Header } from './components/Header';
import { CrownBanner } from './components/CrownBanner';
import { TakeCard } from './components/TakeCard';
import { CreateTakeModal } from './components/CreateTakeModal';
import { GauntletMode } from './components/GauntletMode';
import { HallOfFameModal } from './components/HallOfFameModal';

export default function App() {
  const [takes, setTakes] = useState<HotTake[]>(getStoredTakes);
  const [userVotes, setUserVotes] = useState<Record<string, 'agree' | 'disagree'>>(getUserVotes);
  const [argumentsMap, setArgumentsMap] = useState<Record<string, Argument[]>>(getStoredArguments);
  const [soundEnabled, setSoundState] = useState<boolean>(getSoundSetting);

  // Navigation & Filtering State
  const [currentTab, setCurrentTab] = useState<'feed' | 'gauntlet' | 'crown'>('feed');
  const [selectedCategory, setSelectedCategory] = useState<Category>('all');
  const [sortMode, setSortMode] = useState<SortMode>('controversial');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedDebateId, setExpandedDebateId] = useState<string | null>(null);

  // Modals
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isHallOfFameOpen, setIsHallOfFameOpen] = useState(false);

  // Sync sound engine with state
  useEffect(() => {
    sound.enabled = soundEnabled;
  }, [soundEnabled]);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundState(next);
    setSoundSetting(next);
    sound.enabled = next;
    if (next) sound.playPop();
  };

  // Identify the Crowned Take (Highest controversy score in the system)
  const crownedTake = useMemo(() => {
    if (takes.length === 0) return null;
    let highestScore = -1;
    let champion = takes[0];
    for (const t of takes) {
      const score = calculateControversy(t.agreeCount, t.disagreeCount);
      if (score > highestScore) {
        highestScore = score;
        champion = t;
      }
    }
    return champion;
  }, [takes]);

  // Handle Voting
  const handleVote = (takeId: string, stance: 'agree' | 'disagree') => {
    const currentVote = userVotes[takeId];
    if (currentVote === stance) {
      // User tapped their existing vote, keep it or play feedback
      if (stance === 'agree') sound.playFire();
      else sound.playIce();
      return;
    }

    // Play appropriate sound effect
    if (stance === 'agree') sound.playFire();
    else sound.playIce();

    const updatedTakes = takes.map((take) => {
      if (take.id !== takeId) return take;

      let agree = take.agreeCount;
      let disagree = take.disagreeCount;

      if (currentVote === 'agree') agree = Math.max(0, agree - 1);
      if (currentVote === 'disagree') disagree = Math.max(0, disagree - 1);

      if (stance === 'agree') agree += 1;
      if (stance === 'disagree') disagree += 1;

      return {
        ...take,
        agreeCount: agree,
        disagreeCount: disagree,
      };
    });

    setTakes(updatedTakes);
    saveStoredTakes(updatedTakes);

    const updatedVotes = saveUserVote(takeId, stance);
    setUserVotes({ ...updatedVotes });
  };

  // Handle Adding Argument
  const handleAddArgument = (
    takeId: string,
    content: string,
    stance: 'agree' | 'disagree',
    author: string
  ) => {
    sound.playPop();
    const newArg: Argument = {
      id: `arg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      takeId,
      author,
      avatarSeed: author.slice(0, 2).toUpperCase(),
      stance,
      content,
      likes: 1,
      createdAt: new Date().toISOString(),
    };

    const currentList = argumentsMap[takeId] || [];
    const nextArgumentsMap = {
      ...argumentsMap,
      [takeId]: [newArg, ...currentList],
    };

    setArgumentsMap(nextArgumentsMap);
    saveStoredArguments(nextArgumentsMap);

    // Increment take comment count
    const updatedTakes = takes.map((t) => {
      if (t.id === takeId) {
        return { ...t, commentsCount: (t.commentsCount || 0) + 1 };
      }
      return t;
    });
    setTakes(updatedTakes);
    saveStoredTakes(updatedTakes);
  };

  // Handle Liking Argument
  const handleLikeArgument = (takeId: string, argId: string) => {
    sound.playPop();
    const currentList = argumentsMap[takeId] || [];
    const updatedList = currentList.map((arg) => {
      if (arg.id === argId) {
        return { ...arg, likes: arg.likes + 1 };
      }
      return arg;
    });

    const nextArgumentsMap = {
      ...argumentsMap,
      [takeId]: updatedList,
    };
    setArgumentsMap(nextArgumentsMap);
    saveStoredArguments(nextArgumentsMap);
  };

  // Handle Creating a new Hot Take
  const handleCreateTake = (newTakeData: {
    statement: string;
    elaboration?: string;
    category: Exclude<Category, 'all'>;
    spiceLevel: SpiceLevel;
    author: string;
  }) => {
    sound.playFire();
    const newTake: HotTake = {
      id: `take-${Date.now()}`,
      statement: newTakeData.statement,
      elaboration: newTakeData.elaboration,
      category: newTakeData.category,
      spiceLevel: newTakeData.spiceLevel,
      author: newTakeData.author,
      agreeCount: 1,
      disagreeCount: 1, // Start with balanced 1/1 seed vote
      createdAt: new Date().toISOString(),
      commentsCount: 0,
      tags: [newTakeData.category],
    };

    const nextTakes = [newTake, ...takes];
    setTakes(nextTakes);
    saveStoredTakes(nextTakes);

    // Auto vote agree for creator
    const nextVotes = saveUserVote(newTake.id, 'agree');
    setUserVotes({ ...nextVotes });
  };

  // Filtered & Sorted Takes
  const processedTakes = useMemo(() => {
    let result = [...takes];

    // Category filter
    if (selectedCategory !== 'all') {
      result = result.filter((t) => t.category === selectedCategory);
    }

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (t) =>
          t.statement.toLowerCase().includes(q) ||
          t.author.toLowerCase().includes(q) ||
          (t.elaboration && t.elaboration.toLowerCase().includes(q))
      );
    }

    // Sorting
    result.sort((a, b) => {
      if (sortMode === 'controversial') {
        const scoreA = calculateControversy(a.agreeCount, a.disagreeCount);
        const scoreB = calculateControversy(b.agreeCount, b.disagreeCount);
        return scoreB - scoreA;
      }
      if (sortMode === 'spiciest') {
        const spiceWeight: Record<SpiceLevel, number> = {
          nuclear: 4,
          spicy: 3,
          medium: 2,
          mild: 1,
        };
        return spiceWeight[b.spiceLevel] - spiceWeight[a.spiceLevel];
      }
      if (sortMode === 'agreed') {
        const totalA = a.agreeCount + a.disagreeCount;
        const totalB = b.agreeCount + b.disagreeCount;
        const pctA = totalA > 0 ? a.agreeCount / totalA : 0;
        const pctB = totalB > 0 ? b.agreeCount / totalB : 0;
        return pctB - pctA;
      }
      if (sortMode === 'disagreed') {
        const totalA = a.agreeCount + a.disagreeCount;
        const totalB = b.agreeCount + b.disagreeCount;
        const pctA = totalA > 0 ? a.disagreeCount / totalA : 0;
        const pctB = totalB > 0 ? b.disagreeCount / totalB : 0;
        return pctB - pctA;
      }
      // Newest
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

    return result;
  }, [takes, selectedCategory, sortMode, searchQuery]);

  const categoriesList: { key: Category; label: string }[] = [
    { key: 'all', label: 'All Arenas' },
    { key: 'food', label: 'Food & Dining' },
    { key: 'tech', label: 'Tech & AI' },
    { key: 'gaming', label: 'Gaming' },
    { key: 'workplace', label: 'Workplace' },
    { key: 'pop_culture', label: 'Pop Culture' },
    { key: 'life_philosophy', label: 'Philosophy' },
  ];

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* 3-Zone Top Bar */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          sound.playPop();
          setCurrentTab(tab);
        }}
        onOpenCreate={() => setIsCreateOpen(true)}
        onOpenHallOfFame={() => setIsHallOfFameOpen(true)}
        soundEnabled={soundEnabled}
        onToggleSound={toggleSound}
        totalTakesCount={takes.length}
      />

      {/* Main Container */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* Gauntlet Mode View */}
        {currentTab === 'gauntlet' ? (
          <GauntletMode
            takes={takes}
            userVotes={userVotes}
            onVote={handleVote}
            onExit={() => setCurrentTab('feed')}
          />
        ) : (
          <>
            {/* Weekly Most Controversial Crown Section */}
            {crownedTake && (
              <section aria-label="Weekly Most Controversial Crown">
                <CrownBanner
                  crownedTake={crownedTake}
                  onVote={handleVote}
                  userVote={userVotes[crownedTake.id]}
                  onOpenDebate={(id) => {
                    setExpandedDebateId(id);
                    setCurrentTab('feed');
                  }}
                  onOpenHallOfFame={() => setIsHallOfFameOpen(true)}
                />
              </section>
            )}

            {/* If Crown Tab is selected, show explanation of how the Weekly Crown works */}
            {currentTab === 'crown' && (
              <section className="rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 space-y-4">
                <div className="flex items-center gap-2 text-amber-400 font-semibold text-sm">
                  <Trophy className="h-4 w-4" />
                  <span>The Mathematics of Controversy</span>
                </div>
                <p className="text-xs text-neutral-300 leading-relaxed max-w-3xl">
                  In Hot Take Arena, the Weekly Crown does not go to the most loved or the most hated opinion. 
                  Consensus is easy. True controversy is an exact <strong>50% / 50% deadlock</strong> with high vote volume, 
                  where two armies of equal passion clash. The Controversy Index measures parity, engagement volume, and debate intensity.
                </p>
                <div className="flex items-center gap-4 text-xs text-neutral-400 pt-2 border-t border-neutral-800">
                  <span>Current Leader: <strong className="text-white">@{crownedTake?.author}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>Formula: Parity Balance × Log₁₀(Votes)</span>
                  <span aria-hidden="true">·</span>
                  <button
                    onClick={() => setIsHallOfFameOpen(true)}
                    className="text-amber-400 hover:underline"
                  >
                    View Previous Hall of Fame Winners →
                  </button>
                </div>
              </section>
            )}

            {/* Filter & Sorting Controls (Zero-pill compliant segmented controls) */}
            <section className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                {/* Search Bar */}
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-neutral-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search takes by topic, keyword, or author..."
                    className="w-full rounded-xl border border-neutral-800 bg-neutral-900/90 pl-10 pr-4 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:border-neutral-600 focus:outline-none transition-colors"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-neutral-500 hover:text-white"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* Sort Mode Segmented Control */}
                <div className="flex items-center gap-1 p-1 bg-neutral-900 rounded-xl border border-neutral-800 text-xs overflow-x-auto">
                  <button
                    onClick={() => setSortMode('controversial')}
                    className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                      sortMode === 'controversial'
                        ? 'bg-neutral-800 text-amber-400 shadow-sm font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <Trophy className="h-3.5 w-3.5" />
                    Controversial
                  </button>
                  <button
                    onClick={() => setSortMode('spiciest')}
                    className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                      sortMode === 'spiciest'
                        ? 'bg-neutral-800 text-orange-400 shadow-sm font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <Flame className="h-3.5 w-3.5" />
                    Nuclear Spice
                  </button>
                  <button
                    onClick={() => setSortMode('agreed')}
                    className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                      sortMode === 'agreed'
                        ? 'bg-neutral-800 text-emerald-400 shadow-sm font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <TrendingUp className="h-3.5 w-3.5" />
                    Top Agreed
                  </button>
                  <button
                    onClick={() => setSortMode('disagreed')}
                    className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                      sortMode === 'disagreed'
                        ? 'bg-neutral-800 text-cyan-400 shadow-sm font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <Snowflake className="h-3.5 w-3.5" />
                    Ice Cold
                  </button>
                  <button
                    onClick={() => setSortMode('newest')}
                    className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors flex items-center gap-1.5 ${
                      sortMode === 'newest'
                        ? 'bg-neutral-800 text-white shadow-sm font-semibold'
                        : 'text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <Clock className="h-3.5 w-3.5" />
                    Fresh
                  </button>
                </div>
              </div>

              {/* Category Filter Tabs */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
                {categoriesList.map((cat) => (
                  <button
                    key={cat.key}
                    onClick={() => {
                      sound.playPop();
                      setSelectedCategory(cat.key);
                    }}
                    className={`px-3.5 py-1.5 rounded-lg font-medium whitespace-nowrap border transition-all ${
                      selectedCategory === cat.key
                        ? 'border-orange-500 bg-orange-600/10 text-orange-400 font-semibold'
                        : 'border-neutral-800 bg-neutral-900/60 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </section>

            {/* Hot Takes Feed */}
            <section className="space-y-4" aria-label="Arena Feed">
              {processedTakes.length === 0 ? (
                <div className="rounded-xl border border-neutral-800 bg-neutral-900/50 p-12 text-center">
                  <p className="text-sm text-neutral-400">
                    No hot takes matched your filter or search query.
                  </p>
                  <button
                    onClick={() => {
                      setSelectedCategory('all');
                      setSearchQuery('');
                    }}
                    className="mt-3 text-xs text-orange-400 hover:underline"
                  >
                    Reset filters
                  </button>
                </div>
              ) : (
                processedTakes.map((take) => (
                  <TakeCard
                    key={take.id}
                    take={take}
                    onVote={handleVote}
                    userVote={userVotes[take.id]}
                    argumentsList={argumentsMap[take.id] || []}
                    onAddArgument={handleAddArgument}
                    onLikeArgument={handleLikeArgument}
                    isExpandedDebate={expandedDebateId === take.id}
                    onToggleDebate={(id) => {
                      sound.playPop();
                      setExpandedDebateId(expandedDebateId === id ? null : id);
                    }}
                  />
                ))
              )}
            </section>
          </>
        )}
      </main>

      {/* Footer (Anti-slop compliant: Quiet copyright & links only) */}
      <footer className="border-t border-neutral-900 py-6 text-center text-xs text-neutral-400">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>© {new Date().getFullYear()} Hot Take Arena. Stand on your hill.</p>
          <div className="flex items-center gap-4 text-neutral-400">
            <span>Agree 🔥</span>
            <span aria-hidden="true">·</span>
            <span>Disagree ❄️</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setIsHallOfFameOpen(true)}
              className="hover:text-amber-400 transition-colors"
            >
              Hall of Fame
            </button>
          </div>
        </div>
      </footer>

      {/* Create Hot Take Modal */}
      <CreateTakeModal
        isOpen={isCreateOpen}
        onClose={() => setIsCreateOpen(false)}
        onSubmit={handleCreateTake}
      />

      {/* Past Champions Hall of Fame Modal */}
      <HallOfFameModal
        isOpen={isHallOfFameOpen}
        onClose={() => setIsHallOfFameOpen(false)}
      />
    </div>
  );
}
