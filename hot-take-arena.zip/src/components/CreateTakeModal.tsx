import React, { useState } from 'react';
import { X, Flame, ShieldAlert, Sparkles } from 'lucide-react';
import { Category, SpiceLevel } from '../types';

interface CreateTakeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (take: {
    statement: string;
    elaboration?: string;
    category: Exclude<Category, 'all'>;
    spiceLevel: SpiceLevel;
    author: string;
  }) => void;
}

export const CreateTakeModal: React.FC<CreateTakeModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [statement, setStatement] = useState('');
  const [elaboration, setElaboration] = useState('');
  const [category, setCategory] = useState<Exclude<Category, 'all'>>('food');
  const [spiceLevel, setSpiceLevel] = useState<SpiceLevel>('spicy');
  const [author, setAuthor] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!statement.trim()) return;

    onSubmit({
      statement: statement.trim(),
      elaboration: elaboration.trim() || undefined,
      category,
      spiceLevel,
      author: author.trim() || 'AnonymousSpicer',
    });

    setStatement('');
    setElaboration('');
    setAuthor('');
    onClose();
  };

  const categories: { key: Exclude<Category, 'all'>; label: string }[] = [
    { key: 'food', label: 'Food & Dining' },
    { key: 'tech', label: 'Tech & AI' },
    { key: 'gaming', label: 'Gaming' },
    { key: 'pop_culture', label: 'Pop Culture' },
    { key: 'life_philosophy', label: 'Philosophy & Life' },
    { key: 'workplace', label: 'Workplace & Career' },
  ];

  const spiceOptions: { level: SpiceLevel; label: string; desc: string; icon: string }[] = [
    { level: 'mild', label: 'Mild', desc: 'Warm take, polite disagreement', icon: '🌶️' },
    { level: 'medium', label: 'Medium', desc: 'Strong friction, eyebrows raised', icon: '🌶️🌶️' },
    { level: 'spicy', label: 'Spicy', desc: 'Direct attack on conventional wisdom', icon: '🌶️🌶️🌶️' },
    { level: 'nuclear', label: 'Nuclear', desc: 'Friendship ending, scorched earth', icon: '🌋' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-lg rounded-2xl border border-neutral-800 bg-neutral-900 p-6 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-orange-600/20 text-orange-500">
              <Flame className="h-4 w-4" />
            </div>
            <h2 className="font-display text-lg font-bold text-white">
              Drop a Spicy Hot Take
            </h2>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {/* Statement */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1.5">
              <label className="font-medium text-neutral-300">
                Your Hot Take <span className="text-orange-500">*</span>
              </label>
              <span className={`tabular-nums ${statement.length > 250 ? 'text-amber-400' : 'text-neutral-500'}`}>
                {statement.length}/280
              </span>
            </div>
            <textarea
              required
              maxLength={280}
              rows={3}
              value={statement}
              onChange={(e) => setStatement(e.target.value)}
              placeholder="e.g. Cereal is cold soup and cow milk is broth. Or: Single player games with 20m cutscenes are failed movies..."
              className="w-full rounded-lg border border-neutral-800 bg-neutral-950 px-3 py-2 text-sm text-white placeholder-neutral-500 focus:border-orange-500 focus:outline-none"
            />
          </div>

          {/* Category */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">
              Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
              {categories.map((c) => (
                <button
                  type="button"
                  key={c.key}
                  onClick={() => setCategory(c.key)}
                  className={`px-2.5 py-1.5 rounded-lg text-xs font-medium border text-left transition-all ${
                    category === c.key
                      ? 'border-orange-500 bg-orange-500/10 text-orange-400 font-semibold'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* Spice Level */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">
              Spice Calibration
            </label>
            <div className="grid grid-cols-2 gap-2">
              {spiceOptions.map((s) => (
                <button
                  type="button"
                  key={s.level}
                  onClick={() => setSpiceLevel(s.level)}
                  className={`flex flex-col text-left p-2.5 rounded-lg border transition-all ${
                    spiceLevel === s.level
                      ? 'border-orange-500 bg-orange-950/20 text-white'
                      : 'border-neutral-800 bg-neutral-950 text-neutral-400 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span>{s.label}</span>
                    <span>{s.icon}</span>
                  </div>
                  <span className="text-[11px] text-neutral-500 mt-0.5 line-clamp-1">
                    {s.desc}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Elaboration / Hill to die on */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">
              Author Defense <span className="text-neutral-500 font-normal">(Why do you believe this?)</span>
            </label>
            <textarea
              rows={2}
              value={elaboration}
              onChange={(e) => setElaboration(e.target.value)}
              placeholder="Provide your rationale, empirical proof, or unhinged logic..."
              className="w-full rounded-lg border border-neutral-800 bg-neutral-950 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-neutral-700 focus:outline-none"
            />
          </div>

          {/* Author */}
          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1.5">
              Gladiator Alias
            </label>
            <input
              type="text"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="e.g. SizzleKing (or leave blank for anonymous)"
              className="w-full rounded-lg border border-neutral-800 bg-neutral-950 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-neutral-700 focus:outline-none"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center justify-end gap-2 border-t border-neutral-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!statement.trim()}
              className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-orange-600 to-amber-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-orange-950/50 hover:from-orange-500 hover:to-amber-500 disabled:opacity-50 transition-all active:scale-95"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Launch into Arena</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
