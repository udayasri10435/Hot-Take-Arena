import React from 'react';
import { Volume2, VolumeX, Flame, Plus, Trophy, Zap, Compass } from 'lucide-react';

interface HeaderProps {
  currentTab: 'feed' | 'gauntlet' | 'crown';
  onSelectTab: (tab: 'feed' | 'gauntlet' | 'crown') => void;
  onOpenCreate: () => void;
  onOpenHallOfFame: () => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
  totalTakesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  onOpenCreate,
  onOpenHallOfFame,
  soundEnabled,
  onToggleSound,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800 bg-neutral-950/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => onSelectTab('feed')}
          className="group flex items-center gap-2.5 text-left focus-visible:outline-none"
        >
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-orange-600/20 text-orange-500 ring-1 ring-orange-500/30 transition-transform group-hover:scale-105">
            <Flame className="h-5 w-5 fill-orange-500 text-orange-500" />
          </div>
          <span className="font-display text-xl font-extrabold tracking-tight text-white group-hover:text-orange-400 transition-colors">
            Hot Take Arena
          </span>
        </button>

        {/* Zone 2: 4 clean text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-400">
          <button
            onClick={() => onSelectTab('feed')}
            className={`transition-colors flex items-center gap-1.5 hover:text-white ${
              currentTab === 'feed' ? 'text-orange-400 font-semibold' : ''
            }`}
          >
            <Compass className="h-4 w-4" />
            Arena Feed
          </button>
          <button
            onClick={() => onSelectTab('crown')}
            className={`transition-colors flex items-center gap-1.5 hover:text-white ${
              currentTab === 'crown' ? 'text-amber-400 font-semibold' : ''
            }`}
          >
            <Trophy className="h-4 w-4" />
            Weekly Crown
          </button>
          <button
            onClick={() => onSelectTab('gauntlet')}
            className={`transition-colors flex items-center gap-1.5 hover:text-white ${
              currentTab === 'gauntlet' ? 'text-cyan-400 font-semibold' : ''
            }`}
          >
            <Zap className="h-4 w-4" />
            Speed Gauntlet
          </button>
          <button
            onClick={onOpenHallOfFame}
            className="transition-colors hover:text-white"
          >
            Hall of Fame
          </button>
        </nav>

        {/* Zone 3: Primary actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSound}
            aria-label={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            title={soundEnabled ? 'Sound FX On' : 'Sound FX Muted'}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-neutral-800 bg-neutral-900 text-neutral-400 hover:text-white hover:border-neutral-700 transition-colors"
          >
            {soundEnabled ? (
              <Volume2 className="h-4 w-4 text-orange-400" />
            ) : (
              <VolumeX className="h-4 w-4 text-neutral-500" />
            )}
          </button>

          <button
            onClick={onOpenCreate}
            className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-orange-600 to-amber-600 px-3.5 py-2 text-xs font-semibold text-white shadow-lg shadow-orange-950/40 hover:from-orange-500 hover:to-amber-500 transition-all active:scale-95 whitespace-nowrap"
          >
            <Plus className="h-4 w-4" />
            <span>Drop Hot Take</span>
          </button>
        </div>
      </div>
    </header>
  );
};
