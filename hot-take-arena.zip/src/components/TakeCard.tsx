import React, { useState } from 'react';
import { Flame, Snowflake, MessageSquare, Share2, Check, ChevronDown, ChevronUp, ThumbsUp, Send } from 'lucide-react';
import { HotTake, Argument } from '../types';
import { calculateControversy } from '../utils/storage';

interface TakeCardProps {
  take: HotTake;
  onVote: (takeId: string, stance: 'agree' | 'disagree') => void;
  userVote?: 'agree' | 'disagree';
  argumentsList: Argument[];
  onAddArgument: (takeId: string, content: string, stance: 'agree' | 'disagree', author: string) => void;
  onLikeArgument: (takeId: string, argId: string) => void;
  isExpandedDebate?: boolean;
  onToggleDebate: (takeId: string) => void;
}

export const TakeCard: React.FC<TakeCardProps> = ({
  take,
  onVote,
  userVote,
  argumentsList,
  onAddArgument,
  onLikeArgument,
  isExpandedDebate,
  onToggleDebate,
}) => {
  const [copied, setCopied] = useState(false);
  const [showDefense, setShowDefense] = useState(false);
  const [newArgText, setNewArgText] = useState('');
  const [newArgStance, setNewArgStance] = useState<'agree' | 'disagree'>('agree');
  const [newArgAuthor, setNewArgAuthor] = useState('');

  const total = take.agreeCount + take.disagreeCount;
  const agreePct = total > 0 ? ((take.agreeCount / total) * 100).toFixed(1) : '50.0';
  const disagreePct = total > 0 ? ((take.disagreeCount / total) * 100).toFixed(1) : '50.0';
  const controversy = calculateControversy(take.agreeCount, take.disagreeCount);

  const handleCopy = () => {
    const textToCopy = `"${take.statement}" — Vote on Hot Take Arena`;
    navigator.clipboard?.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePostArgument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newArgText.trim()) return;
    onAddArgument(
      take.id,
      newArgText.trim(),
      newArgStance,
      newArgAuthor.trim() || 'AnonymousGladiator'
    );
    setNewArgText('');
  };

  // Spice representation
  const spiceLabel = {
    mild: 'Mild · 🌶️',
    medium: 'Medium · 🌶️🌶️',
    spicy: 'Spicy · 🌶️🌶️🌶️',
    nuclear: 'Nuclear · 🌋',
  }[take.spiceLevel];

  const spiceColor = {
    mild: 'text-emerald-400',
    medium: 'text-amber-400',
    spicy: 'text-orange-400',
    nuclear: 'text-rose-400 font-semibold',
  }[take.spiceLevel];

  return (
    <article className="group relative rounded-xl border border-neutral-800 bg-neutral-900/90 p-5 sm:p-6 transition-all hover:border-neutral-700/80 hover:bg-neutral-900 shadow-sm">
      {/* Top Metadata Line (Strict Zero-Pill) */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <span className="font-medium text-neutral-300">@{take.author}</span>
          <span aria-hidden="true">·</span>
          <span className="capitalize">{take.category.replace('_', ' ')}</span>
          <span aria-hidden="true">·</span>
          <span className={spiceColor}>{spiceLabel}</span>
        </div>

        <div className="flex items-center gap-2 tabular-nums">
          <span className="text-neutral-400 text-[11px]">Controversy {controversy}/100</span>
          {controversy >= 90 && (
            <span className="text-amber-400 text-[11px] font-medium">★ Crown Contender</span>
          )}
        </div>
      </div>

      {/* Main Hot Take Statement */}
      <div className="mt-3">
        <h3 className="font-display text-lg sm:text-xl font-bold leading-relaxed text-neutral-100 text-balance">
          "{take.statement}"
        </h3>
      </div>

      {/* Defense / Hill to Die On Note */}
      {take.elaboration && (
        <div className="mt-3">
          <button
            onClick={() => setShowDefense(!showDefense)}
            className="flex items-center gap-1.5 text-xs font-medium text-neutral-400 hover:text-neutral-200 transition-colors"
          >
            <span>{showDefense ? 'Hide Author Defense' : 'Read Author Defense'}</span>
            {showDefense ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
          </button>
          {showDefense && (
            <div className="mt-2 rounded-lg border-l-2 border-orange-500 bg-neutral-950/60 p-3 text-xs leading-relaxed text-neutral-300">
              {take.elaboration}
            </div>
          )}
        </div>
      )}

      {/* Tug of War Visual Meter */}
      <div className="mt-5 space-y-1.5">
        <div className="flex items-center justify-between text-xs font-semibold tabular-nums">
          <span className="flex items-center gap-1.5 text-orange-400">
            <Flame className="h-3.5 w-3.5 fill-orange-400" />
            Agree {agreePct}%
          </span>
          <span className="text-neutral-500 text-[11px]">
            {total.toLocaleString()} votes
          </span>
          <span className="flex items-center gap-1.5 text-cyan-400">
            Disagree {disagreePct}%
            <Snowflake className="h-3.5 w-3.5" />
          </span>
        </div>

        {/* Tug bar */}
        <div className="relative h-2 w-full overflow-hidden rounded-full bg-neutral-800">
          <div
            className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-orange-500 to-amber-500 transition-all duration-300"
            style={{ width: `${agreePct}%` }}
          />
          <div
            className="absolute right-0 top-0 bottom-0 bg-gradient-to-l from-cyan-500 to-blue-500 transition-all duration-300"
            style={{ width: `${disagreePct}%` }}
          />
          {/* 50% dead center line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 bg-white/40" />
        </div>
      </div>

      {/* Interactive Action Bar */}
      <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-neutral-800/80 pt-4">
        {/* Voting Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onVote(take.id, 'agree')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all active:scale-95 ${
              userVote === 'agree'
                ? 'bg-orange-600 text-white shadow-md shadow-orange-950/60 ring-1 ring-orange-400'
                : 'border border-neutral-700/80 bg-neutral-800 text-neutral-300 hover:border-orange-500/60 hover:bg-neutral-800/80'
            }`}
          >
            <Flame className="h-4 w-4" />
            <span>Agree ({take.agreeCount.toLocaleString()})</span>
          </button>

          <button
            onClick={() => onVote(take.id, 'disagree')}
            className={`flex items-center gap-2 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all active:scale-95 ${
              userVote === 'disagree'
                ? 'bg-cyan-600 text-white shadow-md shadow-cyan-950/60 ring-1 ring-cyan-400'
                : 'border border-neutral-700/80 bg-neutral-800 text-neutral-300 hover:border-cyan-500/60 hover:bg-neutral-800/80'
            }`}
          >
            <Snowflake className="h-4 w-4" />
            <span>Disagree ({take.disagreeCount.toLocaleString()})</span>
          </button>
        </div>

        {/* Secondary controls: Debate & Share */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onToggleDebate(take.id)}
            className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-medium transition-colors ${
              isExpandedDebate
                ? 'border-neutral-600 bg-neutral-800 text-white'
                : 'border-neutral-800 bg-neutral-900 text-neutral-400 hover:border-neutral-700 hover:text-neutral-200'
            }`}
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>Debate ({take.commentsCount || argumentsList.length})</span>
          </button>

          <button
            onClick={handleCopy}
            className="flex items-center gap-1 rounded-lg border border-neutral-800 bg-neutral-900 px-2.5 py-1.5 text-xs text-neutral-400 hover:border-neutral-700 hover:text-neutral-200 transition-colors"
            title="Share Take"
          >
            {copied ? (
              <span className="flex items-center gap-1 text-emerald-400">
                <Check className="h-3.5 w-3.5" /> Copied
              </span>
            ) : (
              <Share2 className="h-3.5 w-3.5" />
            )}
          </button>
        </div>
      </div>

      {/* Expandable Debate Section */}
      {isExpandedDebate && (
        <div className="mt-5 border-t border-neutral-800/80 pt-4 space-y-4">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span className="font-semibold text-neutral-300 uppercase tracking-wider text-[11px]">
              Arena Arguments & Rebuttals
            </span>
            <span>{argumentsList.length} fighters in the ring</span>
          </div>

          {/* New Argument Input */}
          <form onSubmit={handlePostArgument} className="space-y-3 rounded-lg bg-neutral-950/70 p-3.5 border border-neutral-800">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs text-neutral-400">Pitch your defense or counter:</span>
              <div className="flex items-center gap-1 p-0.5 rounded-md bg-neutral-900 border border-neutral-800 text-xs">
                <button
                  type="button"
                  onClick={() => setNewArgStance('agree')}
                  className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 ${
                    newArgStance === 'agree'
                      ? 'bg-orange-600 text-white font-medium'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Flame className="h-3 w-3" /> In Favor
                </button>
                <button
                  type="button"
                  onClick={() => setNewArgStance('disagree')}
                  className={`px-2.5 py-1 rounded transition-colors flex items-center gap-1 ${
                    newArgStance === 'disagree'
                      ? 'bg-cyan-600 text-white font-medium'
                      : 'text-neutral-400 hover:text-neutral-200'
                  }`}
                >
                  <Snowflake className="h-3 w-3" /> Rebuttal
                </button>
              </div>
            </div>

            <textarea
              rows={2}
              value={newArgText}
              onChange={(e) => setNewArgText(e.target.value)}
              placeholder={newArgStance === 'agree' ? 'Why this take is 100% facts...' : 'Why this take is utterly delusional...'}
              className="w-full rounded-md border border-neutral-800 bg-neutral-900 px-3 py-2 text-xs text-neutral-200 placeholder-neutral-500 focus:border-neutral-600 focus:outline-none"
            />

            <div className="flex items-center justify-between gap-2">
              <input
                type="text"
                value={newArgAuthor}
                onChange={(e) => setNewArgAuthor(e.target.value)}
                placeholder="Your gladiator handle (optional)"
                className="max-w-[200px] rounded-md border border-neutral-800 bg-neutral-900 px-2.5 py-1 text-xs text-neutral-300 placeholder-neutral-500 focus:outline-none"
              />

              <button
                type="submit"
                disabled={!newArgText.trim()}
                className="flex items-center gap-1.5 rounded-md bg-neutral-100 px-3 py-1 text-xs font-semibold text-neutral-900 hover:bg-white disabled:opacity-40 transition-colors"
              >
                <Send className="h-3 w-3" />
                <span>Drop Argument</span>
              </button>
            </div>
          </form>

          {/* List of arguments */}
          <div className="space-y-2.5">
            {argumentsList.length === 0 ? (
              <p className="text-center py-4 text-xs text-neutral-500">
                No one has dared enter the ring yet. Be the first to defend or tear down this take!
              </p>
            ) : (
              argumentsList.map((arg) => (
                <div
                  key={arg.id}
                  className={`rounded-lg border p-3 text-xs leading-relaxed ${
                    arg.stance === 'agree'
                      ? 'border-orange-950/60 bg-neutral-950/40 text-neutral-200'
                      : 'border-cyan-950/60 bg-neutral-950/40 text-neutral-200'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2 mb-1.5 text-neutral-400">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-neutral-300">@{arg.author}</span>
                      <span aria-hidden="true">·</span>
                      <span
                        className={
                          arg.stance === 'agree'
                            ? 'text-orange-400 font-medium'
                            : 'text-cyan-400 font-medium'
                        }
                      >
                        {arg.stance === 'agree' ? '🔥 Defense' : '❄️ Counter'}
                      </span>
                    </div>

                    <button
                      onClick={() => onLikeArgument(take.id, arg.id)}
                      className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-white transition-colors"
                    >
                      <ThumbsUp className="h-3 w-3" />
                      <span className="tabular-nums">{arg.likes}</span>
                    </button>
                  </div>
                  <p>{arg.content}</p>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </article>
  );
};
