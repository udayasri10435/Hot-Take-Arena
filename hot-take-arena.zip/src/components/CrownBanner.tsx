import React from 'react';
import { Crown, Sparkles, Flame, Snowflake, MessageSquare, History, ChevronRight } from 'lucide-react';
import { HotTake } from '../types';
import { calculateControversy } from '../utils/storage';

interface CrownBannerProps {
  crownedTake: HotTake;
  onVote: (takeId: string, stance: 'agree' | 'disagree') => void;
  userVote?: 'agree' | 'disagree';
  onOpenDebate: (takeId: string) => void;
  onOpenHallOfFame: () => void;
}

export const CrownBanner: React.FC<CrownBannerProps> = ({
  crownedTake,
  onVote,
  userVote,
  onOpenDebate,
  onOpenHallOfFame,
}) => {
  const total = crownedTake.agreeCount + crownedTake.disagreeCount;
  const agreePct = total > 0 ? ((crownedTake.agreeCount / total) * 100).toFixed(1) : '50.0';
  const disagreePct = total > 0 ? ((crownedTake.disagreeCount / total) * 100).toFixed(1) : '50.0';
  const controversy = calculateControversy(crownedTake.agreeCount, crownedTake.disagreeCount);

  return (
    <div className="relative overflow-hidden rounded-2xl border border-amber-500/30 bg-gradient-to-b from-neutral-900 via-neutral-900 to-neutral-950 p-6 sm:p-8 shadow-2xl shadow-amber-950/20">
      {/* Background warm ambient glow */}
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -right-20 -top-20 h-72 w-72 rounded-full bg-amber-500/10 blur-3xl"
      />
      <div 
        aria-hidden="true" 
        className="pointer-events-none absolute -left-20 -bottom-20 h-72 w-72 rounded-full bg-orange-600/10 blur-3xl"
      />

      {/* Top row kicker & metadata (Zero-pill compliant) */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-md bg-amber-500/20 text-amber-400 ring-1 ring-amber-500/40">
            <Crown className="h-3.5 w-3.5 fill-amber-400" />
          </div>
          <span className="font-semibold uppercase tracking-wider text-amber-400">
            Weekly Most Controversial Crown
          </span>
          <span aria-hidden="true">·</span>
          <span>Week 39 Arena Cycle</span>
          <span aria-hidden="true">·</span>
          <span className="text-amber-300 font-medium">Controversy Index: {controversy}/100</span>
        </div>

        <button
          onClick={onOpenHallOfFame}
          className="group flex items-center gap-1.5 text-xs font-medium text-neutral-400 hover:text-amber-300 transition-colors"
        >
          <History className="h-3.5 w-3.5" />
          <span>Past Crown Champions</span>
          <ChevronRight className="h-3 w-3 transition-transform group-hover:translate-x-0.5" />
        </button>
      </div>

      {/* Main statement in high-impact font */}
      <div className="mt-4 mb-6">
        <p className="font-display text-xl sm:text-2xl lg:text-3xl font-bold leading-snug tracking-tight text-white max-w-4xl text-balance">
          "{crownedTake.statement}"
        </p>
        {crownedTake.elaboration && (
          <p className="mt-3 text-sm text-neutral-300 leading-relaxed max-w-3xl">
            {crownedTake.elaboration}
          </p>
        )}
      </div>

      {/* Tug of war deadlock gauge */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs font-semibold tabular-nums">
          <span className="flex items-center gap-1.5 text-orange-400">
            <Flame className="h-3.5 w-3.5 fill-orange-400 text-orange-400" />
            Agree {agreePct}% ({crownedTake.agreeCount.toLocaleString()})
          </span>
          <span className="text-neutral-400 text-[11px] font-normal">
            Deadlock Split · {total.toLocaleString()} total votes
          </span>
          <span className="flex items-center gap-1.5 text-cyan-400">
            Disagree {disagreePct}% ({crownedTake.disagreeCount.toLocaleString()})
            <Snowflake className="h-3.5 w-3.5 text-cyan-400" />
          </span>
        </div>

        {/* The visual tug-of-war meter */}
        <div className="relative h-3 w-full overflow-hidden rounded-full bg-neutral-800 ring-1 ring-white/10">
          <div
            className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-orange-600 to-amber-500 transition-all duration-500"
            style={{ width: `${agreePct}%` }}
          />
          <div
            className="absolute right-0 top-0 bottom-0 bg-gradient-to-l from-cyan-600 to-blue-500 transition-all duration-500"
            style={{ width: `${disagreePct}%` }}
          />
          {/* 50% dead-center notch marker */}
          <div className="absolute left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 bg-white/80 shadow-[0_0_8px_white]" />
        </div>
      </div>

      {/* Bottom actions & attribution */}
      <div className="mt-6 flex flex-wrap items-center justify-between gap-4 border-t border-neutral-800/80 pt-4 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <span>Dropped by <strong className="text-neutral-200">@{crownedTake.author}</strong></span>
          <span aria-hidden="true">·</span>
          <span className="capitalize">{crownedTake.category.replace('_', ' ')}</span>
          <span aria-hidden="true">·</span>
          <span className="text-amber-400 flex items-center gap-1">
            <Sparkles className="h-3 w-3" />
            {crownedTake.crownWeekTitle || 'Crowded Deadlock'}
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => onVote(crownedTake.id, 'agree')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all active:scale-95 ${
              userVote === 'agree'
                ? 'bg-orange-600 text-white shadow-lg shadow-orange-900/50'
                : 'border border-neutral-700 bg-neutral-800/80 text-neutral-200 hover:border-orange-500/50 hover:bg-neutral-800'
            }`}
          >
            <Flame className="h-3.5 w-3.5" />
            <span>Agree</span>
          </button>

          <button
            onClick={() => onVote(crownedTake.id, 'disagree')}
            className={`flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all active:scale-95 ${
              userVote === 'disagree'
                ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-900/50'
                : 'border border-neutral-700 bg-neutral-800/80 text-neutral-200 hover:border-cyan-500/50 hover:bg-neutral-800'
            }`}
          >
            <Snowflake className="h-3.5 w-3.5" />
            <span>Disagree</span>
          </button>

          <button
            onClick={() => onOpenDebate(crownedTake.id)}
            className="flex items-center gap-1.5 rounded-lg border border-neutral-700 bg-neutral-800/60 px-3 py-1.5 text-xs font-medium text-neutral-300 hover:bg-neutral-700 hover:text-white transition-colors"
          >
            <MessageSquare className="h-3.5 w-3.5" />
            <span>Debate ({crownedTake.commentsCount})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
