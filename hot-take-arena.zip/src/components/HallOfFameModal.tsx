import React from 'react';
import { X, Trophy, Flame, Snowflake } from 'lucide-react';
import { PAST_CROWNS } from '../utils/storage';

interface HallOfFameModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HallOfFameModal: React.FC<HallOfFameModalProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="relative w-full max-w-2xl rounded-2xl border border-amber-500/30 bg-neutral-900 p-6 sm:p-8 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-800">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/20 text-amber-400 ring-1 ring-amber-500/40">
              <Trophy className="h-4 w-4" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-white">
                Controversy Hall of Fame
              </h2>
              <p className="text-xs text-neutral-400">
                Past champions who achieved the legendary 50/50 community split
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-neutral-400 hover:bg-neutral-800 hover:text-white transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* List of past crowned takes */}
        <div className="mt-4 space-y-4 overflow-y-auto pr-1">
          {PAST_CROWNS.map((crown, idx) => (
            <div
              key={idx}
              className="rounded-xl border border-neutral-800 bg-neutral-950/70 p-5 space-y-3"
            >
              <div className="flex items-center justify-between text-xs text-neutral-400">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-amber-400">{crown.week} Champion</span>
                  <span aria-hidden="true">·</span>
                  <span>@{crown.author}</span>
                  <span aria-hidden="true">·</span>
                  <span>{crown.category}</span>
                </div>
                <span className="text-amber-300 font-semibold tabular-nums">
                  Controversy {crown.controversyScore}/100
                </span>
              </div>

              <p className="font-display text-base font-semibold text-white leading-snug">
                "{crown.statement}"
              </p>

              {/* Tug of war deadlock gauge */}
              <div className="space-y-1 pt-1">
                <div className="flex items-center justify-between text-xs font-semibold tabular-nums">
                  <span className="text-orange-400 flex items-center gap-1">
                    <Flame className="h-3 w-3 fill-orange-400" />
                    {crown.agreePercent}%
                  </span>
                  <span className="text-neutral-500 text-[11px]">
                    {crown.totalVotes.toLocaleString()} votes cast
                  </span>
                  <span className="text-cyan-400 flex items-center gap-1">
                    {crown.disagreePercent}%
                    <Snowflake className="h-3 w-3" />
                  </span>
                </div>

                <div className="relative h-2 w-full overflow-hidden rounded-full bg-neutral-800">
                  <div
                    className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-orange-500 to-amber-500"
                    style={{ width: `${crown.agreePercent}%` }}
                  />
                  <div
                    className="absolute right-0 top-0 bottom-0 bg-gradient-to-l from-cyan-500 to-blue-500"
                    style={{ width: `${crown.disagreePercent}%` }}
                  />
                  <div className="absolute left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 bg-white/70" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="pt-4 mt-4 border-t border-neutral-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-semibold text-white transition-colors"
          >
            Close Hall of Fame
          </button>
        </div>
      </div>
    </div>
  );
};
