import React, { useState, useEffect } from 'react';
import { Flame, Snowflake, ArrowLeft, ArrowRight, RotateCcw, Sparkles } from 'lucide-react';
import { HotTake } from '../types';
import { calculateControversy } from '../utils/storage';

interface GauntletModeProps {
  takes: HotTake[];
  userVotes: Record<string, 'agree' | 'disagree'>;
  onVote: (takeId: string, stance: 'agree' | 'disagree') => void;
  onExit: () => void;
}

export const GauntletMode: React.FC<GauntletModeProps> = ({
  takes,
  userVotes,
  onVote,
  onExit,
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [streak, setStreak] = useState(0);

  const currentTake = takes[currentIndex] || takes[0];
  const totalVotes = currentTake ? currentTake.agreeCount + currentTake.disagreeCount : 0;
  const agreePct = totalVotes > 0 ? Math.round((currentTake.agreeCount / totalVotes) * 100) : 50;
  const disagreePct = 100 - agreePct;
  const controversy = currentTake ? calculateControversy(currentTake.agreeCount, currentTake.disagreeCount) : 0;
  const currentUserVote = currentTake ? userVotes[currentTake.id] : undefined;

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft') {
        handleVote('agree');
      } else if (e.key === 'ArrowRight') {
        handleVote('disagree');
      } else if (e.key === ' ' || e.key === 'Enter') {
        if (revealed) handleNext();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentTake, revealed]);

  const handleVote = (stance: 'agree' | 'disagree') => {
    if (!currentTake) return;
    onVote(currentTake.id, stance);
    setRevealed(true);
    setStreak((prev) => prev + 1);
  };

  const handleNext = () => {
    setRevealed(false);
    if (currentIndex + 1 < takes.length) {
      setCurrentIndex((prev) => prev + 1);
    } else {
      setCurrentIndex(0); // loop or finish
    }
  };

  if (!currentTake) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[500px] text-center p-8">
        <p className="text-neutral-400">No takes available in the gauntlet.</p>
        <button
          onClick={onExit}
          className="mt-4 px-4 py-2 bg-neutral-800 text-white rounded-lg text-sm"
        >
          Return to Arena Feed
        </button>
      </div>
    );
  }

  return (
    <div className="relative mx-auto max-w-2xl px-4 py-8">
      {/* Header bar */}
      <div className="flex items-center justify-between pb-6 text-xs text-neutral-400">
        <button
          onClick={onExit}
          className="flex items-center gap-1.5 text-neutral-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Exit Gauntlet</span>
        </button>

        <div className="flex items-center gap-3">
          <span className="tabular-nums">
            Take {currentIndex + 1} of {takes.length}
          </span>
          <span aria-hidden="true">·</span>
          <span className="text-orange-400 font-medium flex items-center gap-1">
            <Sparkles className="h-3 w-3" />
            Streak: {streak}
          </span>
        </div>
      </div>

      {/* The Central Gauntlet Card */}
      <div className="relative overflow-hidden rounded-2xl border border-neutral-700 bg-neutral-900/95 p-8 sm:p-10 shadow-2xl">
        {/* Subtle background glow */}
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-orange-600/10 blur-3xl"
        />

        {/* Card Metadata */}
        <div className="flex items-center justify-between text-xs text-neutral-400 mb-6">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-300">@{currentTake.author}</span>
            <span aria-hidden="true">·</span>
            <span className="capitalize">{currentTake.category.replace('_', ' ')}</span>
            <span aria-hidden="true">·</span>
            <span className="text-orange-400 uppercase tracking-wide text-[10px] font-semibold">
              {currentTake.spiceLevel}
            </span>
          </div>

          <span className="text-neutral-500 tabular-nums">
            Controversy {controversy}/100
          </span>
        </div>

        {/* Hot Take Statement */}
        <div className="my-8 text-center">
          <p className="font-display text-2xl sm:text-3xl font-bold leading-snug tracking-tight text-white max-w-xl mx-auto text-balance">
            "{currentTake.statement}"
          </p>
          {currentTake.elaboration && (
            <p className="mt-4 text-xs text-neutral-400 max-w-lg mx-auto leading-relaxed italic">
              — "{currentTake.elaboration}"
            </p>
          )}
        </div>

        {/* Result Breakdown (Revealed after voting) */}
        {revealed ? (
          <div className="space-y-4 animate-in fade-in duration-300">
            <div className="rounded-xl bg-neutral-950 p-4 border border-neutral-800">
              <div className="flex items-center justify-between text-xs font-semibold tabular-nums mb-2">
                <span className="text-orange-400 flex items-center gap-1">
                  <Flame className="h-3.5 w-3.5 fill-orange-400" />
                  {agreePct}% Agree
                </span>
                <span className="text-neutral-400 text-[11px]">
                  {currentUserVote ? `You voted ${currentUserVote.toUpperCase()}` : 'Vote Registered'}
                </span>
                <span className="text-cyan-400 flex items-center gap-1">
                  {disagreePct}% Disagree
                  <Snowflake className="h-3.5 w-3.5" />
                </span>
              </div>

              {/* Visual meter */}
              <div className="relative h-3 w-full overflow-hidden rounded-full bg-neutral-800">
                <div
                  className="absolute left-0 top-0 bottom-0 bg-gradient-to-r from-orange-500 to-amber-500 transition-all duration-500"
                  style={{ width: `${agreePct}%` }}
                />
                <div
                  className="absolute right-0 top-0 bottom-0 bg-gradient-to-l from-cyan-500 to-blue-500 transition-all duration-500"
                  style={{ width: `${disagreePct}%` }}
                />
                <div className="absolute left-1/2 top-0 bottom-0 w-0.5 -translate-x-1/2 bg-white/70" />
              </div>

              <p className="text-center text-[11px] text-neutral-400 mt-3">
                {Math.abs(agreePct - disagreePct) <= 6
                  ? '⚔️ Total Civil War! This take is dead-center controversial.'
                  : agreePct > disagreePct
                  ? '🔥 The arena largely sides with this take.'
                  : '❄️ The arena overwhelmingly rejects this take.'}
              </p>
            </div>

            <div className="flex justify-center pt-2">
              <button
                onClick={handleNext}
                className="flex items-center gap-2 rounded-xl bg-white px-6 py-3 text-xs font-bold text-neutral-900 shadow-xl hover:bg-neutral-200 transition-all active:scale-95"
              >
                <span>Next Showdown</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Voting Controls */
          <div className="grid grid-cols-2 gap-4 mt-8">
            <button
              onClick={() => handleVote('agree')}
              className="group flex flex-col items-center justify-center gap-2 rounded-xl border border-neutral-700/80 bg-neutral-800/80 p-5 hover:border-orange-500 hover:bg-neutral-800 transition-all active:scale-95"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-orange-600/20 text-orange-500 group-hover:scale-110 transition-transform">
                <Flame className="h-6 w-6 fill-orange-500 text-orange-500" />
              </div>
              <span className="text-sm font-bold text-white group-hover:text-orange-400">
                Agree
              </span>
              <span className="text-[11px] text-neutral-400">
                Press [ ← ]
              </span>
            </button>

            <button
              onClick={() => handleVote('disagree')}
              className="group flex flex-col items-center justify-center gap-2 rounded-xl border border-neutral-700/80 bg-neutral-800/80 p-5 hover:border-cyan-500 hover:bg-neutral-800 transition-all active:scale-95"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-cyan-600/20 text-cyan-400 group-hover:scale-110 transition-transform">
                <Snowflake className="h-6 w-6 text-cyan-400" />
              </div>
              <span className="text-sm font-bold text-white group-hover:text-cyan-300">
                Disagree
              </span>
              <span className="text-[11px] text-neutral-400">
                Press [ → ]
              </span>
            </button>
          </div>
        )}
      </div>

      {/* Keyboard hints */}
      <div className="mt-6 flex items-center justify-center gap-6 text-xs text-neutral-500">
        <span>Tip: Use keyboard arrows to rapidly blitz through takes</span>
      </div>
    </div>
  );
};
