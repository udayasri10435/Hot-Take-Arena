export type SpiceLevel = 'mild' | 'medium' | 'spicy' | 'nuclear';

export type Category = 
  | 'all'
  | 'food'
  | 'tech'
  | 'gaming'
  | 'pop_culture'
  | 'life_philosophy'
  | 'workplace';

export interface Argument {
  id: string;
  takeId: string;
  author: string;
  avatarSeed: string;
  stance: 'agree' | 'disagree';
  content: string;
  likes: number;
  createdAt: string;
}

export interface HotTake {
  id: string;
  statement: string;
  elaboration?: string;
  author: string;
  category: Exclude<Category, 'all'>;
  spiceLevel: SpiceLevel;
  agreeCount: number;
  disagreeCount: number;
  createdAt: string;
  isWeeklyCrown?: boolean;
  crownWeekTitle?: string;
  commentsCount: number;
  tags?: string[];
}

export interface PastCrown {
  week: string;
  statement: string;
  author: string;
  category: string;
  agreePercent: number;
  disagreePercent: number;
  totalVotes: number;
  controversyScore: number;
}

export type SortMode = 'controversial' | 'spiciest' | 'agreed' | 'disagreed' | 'newest';
